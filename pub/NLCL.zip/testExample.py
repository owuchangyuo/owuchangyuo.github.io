import os

os.system('python test.py --dataroot ./datasets/RealRain --model NLCL --name RealRain --gpu_ids 3 --preprocess None')