import numpy as np
import torch
from .base_model import BaseModel
from . import networks
from .patchnce import PatchNCELoss
import util.util as util
from .disnce import DisNCELoss
import time
import datetime


class NLCLModel(BaseModel):

    @staticmethod
    def modify_commandline_options(parser, is_train=True):
        """  Configures options specific for CUT model
        """
        parser.add_argument('--CUT_mode', type=str, default="CUT", choices='(CUT, cut, FastCUT, fastcut)')

        parser.add_argument('--lambda_GAN', type=float, default=1.0, help='weight for GAN loss：GAN(G(X))')
        parser.add_argument('--lambda_NCE', type=float, default=1.0, help='weight for NCE loss: NCE(G(X), X)')

        parser.add_argument('--lambda_DisNCE', type=float, default=1.0, help='weight for Dis NCE loss')
        parser.add_argument('--lambda_MSE', type=float, default=1.0, help='weight for MSE loss')
        parser.add_argument('--lambda_L1', type=float, default=0.1, help='weight for MSE loss')

        parser.add_argument('--nce_idt', type=util.str2bool, nargs='?', const=True, default=False,
                            help='use NCE loss for identity mapping: NCE(G(Y), Y))')
        parser.add_argument('--adv_nce_layers', type=str, default='0,3,7,11', help='compute NCE loss on which layers')
        parser.add_argument('--gen_nce_layers', type=str, default='0,2,4,8,12', help='compute NCE loss on which layers')
        parser.add_argument('--nce_includes_all_negatives_from_minibatch',
                            type=util.str2bool, nargs='?', const=True, default=False,
                            help='(used for single image translation) If True, include the negatives from the other samples of the minibatch when computing the contrastive loss. Please see models/patchnce.py for more details.')
        parser.add_argument('--netFGen', type=str, default='non_localOne',
                            choices=['mlp_sample', 'non_localOne'])
        parser.add_argument('--netFAdvRain', type=str, default='non_localOne',
                            choices=['mlp_sample', 'non_localOne'])
        parser.add_argument('--netFAdvBack', type=str, default='non_localOne',
                            choices=['mlp_sample', 'non_localOne'])
        parser.add_argument('--netF_nc', type=int, default=256)
        parser.add_argument('--nce_T', type=float, default=0.07, help='temperature for NCE loss')
        parser.add_argument('--num_patches_pos', type=int, default=8, help='number of patches per layer')
        parser.add_argument('--num_patches_neg', type=int, default=128, help='number of patches per layer')
        parser.add_argument('--num_patches', type=int, default=256, help='number of patches per layer')
        parser.add_argument('--flip_equivariance',
                            type=util.str2bool, nargs='?', const=True, default=False,
                            help="Enforce flip-equivariance as additional regularization. It's used by FastCUT, but not CUT")

        parser.set_defaults(pool_size=0)  # no image pooling

        opt, _ = parser.parse_known_args()

        # Set default parameters for CUT and FastCUT
        if opt.CUT_mode.lower() == "cut":
            parser.set_defaults(nce_idt=True, lambda_NCE=1.0,serial_batches=False)
        elif opt.CUT_mode.lower() == "fastcut":
            parser.set_defaults(
                nce_idt=False, lambda_NCE=10.0, flip_equivariance=True,
                n_epochs=150, n_epochs_decay=50
            )
        else:
            raise ValueError(opt.CUT_mode)

        return parser

    def __init__(self, opt):
        BaseModel.__init__(self, opt)

        # specify the training losses you want to print out.
        # The training/test scripts will call <BaseModel.get_current_losses>
        # self.loss_names = ['G_GAN', 'D_real', 'D_fake', 'NCE', 'DisNCE', 'MSE', 'L1']
        self.loss_names = ['G_GAN', 'D_real', 'D_fake', 'DisNCE', 'MSE', 'L1']
        self.visual_names = ['O', 'B', 'pred_B', 'pred_R', 'pred_O']
        if not self.isTrain:
            self.visual_names = ['O','pred_B']
        self.adv_nce_layers = [int(i) for i in self.opt.adv_nce_layers.split(',')]
        self.gen_nce_layers = [int(i) for i in self.opt.gen_nce_layers.split(',')]

        if opt.nce_idt and self.isTrain:
            # self.loss_names += ['NCE_Y']
            self.visual_names += ['idt_B']

        if self.isTrain:
            self.model_names = ['Rain', 'Back', 'GenSample', 'AdvRainSample', 'AdvBackSample', 'D']
            self.pretrained_names = ['Rain', 'Back', 'D']
        else:  # during test time, only load G
            self.model_names = ['Rain', 'Back']
            self.pretrained_names = ['Rain', 'Back']

        self.netRain = networks.Generator(inchannel=3,outchannel=3).to(self.device)
        self.netBack = networks.Generator(inchannel=3,outchannel=3).to(self.device)


    def optimize_parameters(self):
        # forward
        self.forward()
        pass

    def set_input(self, input):
        import os
        AtoB = self.opt.direction == 'AtoB'
        self.O = input['A' if AtoB else 'B'].to(self.device)
        self.B = input['B' if AtoB else 'A'].to(self.device)
        self.image_paths = input['A_paths' if AtoB else 'B_paths']
        self.img_name = input['A_paths'][0]
        self.img_name = os.path.split(self.img_name)
        self.img_name = self.img_name[-1]

    def forward(self):
        self.image_to_transfer = torch.cat((self.O, self.B), dim=0) if self.opt.nce_idt and self.opt.isTrain else self.O
        # self.image_to_transfer = self.O
        if self.opt.flip_equivariance:
            self.flipped_for_equivariance = self.opt.isTrain and (np.random.random() < 0.5)
            if self.flipped_for_equivariance:
                self.image_to_transfer = torch.flip(self.image_to_transfer, [3])
        # torch.cuda.synchronize()
        start_time = datetime.datetime.now()
        (h,w) = self.O.shape[2:]
        self.pred_R = self.netRain(self.O)
        self.image_transferred = self.netBack(self.image_to_transfer)
        # torch.cuda.synchronize()
        end_time = datetime.datetime.now()
        during_time = end_time - start_time
        # print("img size:(%d,%d)test time:%f"%(h,w,during_time))
        print(during_time)
        self.pred_B = self.image_transferred[:self.O.size(0)]
        self.pred_O = self.pred_R + self.pred_B
        if self.opt.nce_idt:
            self.idt_B = self.image_transferred[self.O.size(0):]

